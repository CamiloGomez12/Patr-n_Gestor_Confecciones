<?php include "Views/Templates/header.php"; ?>
<div class="card">
    <div class="card-header bg-primary text-white">
        Ventas
    </div>
    <div class="card-body">
    <table class="table table-white" id="t_historial_e">
    <thead class="thead-white">
        <tr>
            <th>#</th>
            <th>Clientes</th>
            <th>Total</th>
            <th>Fecha Encargo</th>
            <th>Estado</th>
            <th>Plazo</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
       
    </tbody>
</table>
    </div>
</div>
<?php include "Views/Templates/footer.php"; ?>
