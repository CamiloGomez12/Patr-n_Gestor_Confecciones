<?php include "Views/Templates/header.php"; ?>
<div class="card">
    <div class="card-header bg-primary text-white">
        Ventas
    </div>
    <div class="card-body">
    <table class="table table-white" id="t_historial_v">
    <thead class="thead-white">
        <tr>
            <th>#</th>
            <th>Clientes</th>
            <th>Total</th>
            <th>Fecha Venta</th>
            <th>Estado</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
       
    </tbody>
</table>
    </div>
</div>
<?php include "Views/Templates/footer.php"; ?>
