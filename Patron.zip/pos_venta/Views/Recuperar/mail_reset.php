<?php
// Varios destinatarios
$para  = 'cagomez785@misena.edu.co' . ', '; // atención a la coma
//$para .= 'camilogomez724@gmail.com';

// título
$título = 'Patrón (RECUPERAR CONTRASEÑA)';
$codigo= rand(1000,9999);

// mensaje
$mensaje = '
<html>
<head>
  <title>Patrón (RECUPERAR CONTRASEÑA)</title>
</head>
<body>
  <img src="http://localhost/pos_venta/Assets/img/log.PNG"></img>
  <div style="text-aling:center; background-color:#E6E6FA">
  <p>Recuperar contraseña</p>
        <p text-aling-center>Su codigo de recuperación es: </p>
        <h3>'.$codigo.'</h3>


  <p><small>Si usted no ha solicitado un cambio de contraseña hacer caso omiso a este correo</p>
  </div> 
</body>
</html>
';

// Para enviar un correo HTML, debe establecerse la cabecera Content-type
$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
/*
// Cabeceras adicionales
$cabeceras .= 'To: Mary <mary@example.com>, Kelly <kelly@example.com>' . "\r\n";
$cabeceras .= 'From: Recordatorio <cumples@example.com>' . "\r\n";
$cabeceras .= 'Cc: birthdayarchive@example.com' . "\r\n";
$cabeceras .= 'Bcc: birthdaycheck@example.com' . "\r\n";
*/
// Enviarlo
mail($para, $título, $mensaje, $cabeceras);
?>